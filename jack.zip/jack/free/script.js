import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

let scene, camera, renderer, controls;
let pointCloud;
let pose;
let isScanning = false;
let scanData = [];
let scanStartTime = null;
let averageLandmarks = null;
const SCAN_DURATION = 20000; // 20秒
const DEVIATION_THRESHOLD = 0.05; // 5%の閾値

function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
}

function initThree() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0a);

    const fov = window.innerHeight > window.innerWidth ? 90 : 75;
    camera = new THREE.PerspectiveCamera(fov, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 1.5, 3);
    camera.lookAt(0, 1, 0);

    renderer = new THREE.WebGLRenderer({
        antialias: true,
        powerPreference: "high-performance"
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.getElementById('three-container').appendChild(renderer.domElement);

    controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 1, 0);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.screenSpacePanning = true;
    controls.minDistance = 1;
    controls.maxDistance = 10;
    controls.maxPolarAngle = Math.PI - 0.1;
    controls.update();

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const gridHelper = new THREE.GridHelper(10, 10);
    gridHelper.material.opacity = 0.2;
    gridHelper.material.transparent = true;
    scene.add(gridHelper);
}

async function setupPoseDetection() {
    const video = document.getElementById('video');
    const startButton = document.getElementById('startCamera');
    const stopButton = document.getElementById('stopCamera');
    const startScanButton = document.getElementById('startScan');
    const scanStatus = document.getElementById('scanStatus');
    let stream = null;

    pose = new Pose({
        locateFile: (file) => {
            return `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`;
        }
    });

    pose.setOptions({
        modelComplexity: 1,
        smoothLandmarks: true,
        enableSegmentation: false,
        smoothSegmentation: true,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5
    });

    pose.onResults((results) => {
        if (results.poseLandmarks) {
            const landmarks3D = results.poseWorldLandmarks;
            if (landmarks3D) {
                if (isScanning) {
                    scanData.push(landmarks3D);
                    const elapsedTime = Date.now() - scanStartTime;
                    scanStatus.textContent = `Scanning: ${Math.floor((elapsedTime / SCAN_DURATION) * 100)}%`;
                    scanStatus.classList.add('active');
                    
                    if (elapsedTime >= SCAN_DURATION) {
                        isScanning = false;
                        scanStatus.textContent = 'Scan completed';
                        scanStatus.classList.remove('active');
                        createAveragePoseModel();
                    }
                }
                createPointCloudFromPose(landmarks3D);
            }
        }
    });

    async function startCamera() {
        try {
            const constraints = {
                video: {
                    width: { ideal: 1280 },
                    height: { ideal: 720 },
                    frameRate: { ideal: 30 }
                }
            };

            stream = await navigator.mediaDevices.getUserMedia(constraints);
            video.srcObject = stream;
            video.style.display = 'block';
            video.setAttribute('playsinline', '');
            await video.play();

            detectPose();
            scanStatus.textContent = 'Camera ready';
        } catch (error) {
            console.error('Error accessing camera:', error);
            alert('カメラへのアクセスに失敗しました。カメラの許可を確認してください。');
            scanStatus.textContent = 'Camera error';
        }
    }

    function stopCamera() {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            video.srcObject = null;
            video.style.display = 'none';
            scanStatus.textContent = 'Camera stopped';
        }
    }

    async function detectPose() {
        if (video.srcObject) {
            await pose.send({image: video});
            requestAnimationFrame(detectPose);
        }
    }

    startButton.addEventListener('click', startCamera);
    stopButton.addEventListener('click', stopCamera);
    startScanButton.addEventListener('click', () => {
        if (!isScanning && video.srcObject) {
            startScan();
        }
    });

    window.addEventListener('orientationchange', () => {
        setTimeout(() => {
            onWindowResize();
        }, 100);
    });
}

function startScan() {
    isScanning = true;
    scanData = [];
    scanStartTime = Date.now();
    document.getElementById('scanStatus').textContent = 'Scanning started...';
}

function createAveragePoseModel() {
    if (scanData.length === 0) return;

    averageLandmarks = [];
    for (let i = 0; i < scanData[0].length; i++) {
        let sumX = 0, sumY = 0, sumZ = 0;
        scanData.forEach(frame => {
            sumX += frame[i].x;
            sumY += frame[i].y;
            sumZ += frame[i].z;
        });
        averageLandmarks.push({
            x: sumX / scanData.length,
            y: sumY / scanData.length,
            z: sumZ / scanData.length
        });
    }
}

function getPointColor(landmark, index, landmarks3D) {
    if (!averageLandmarks || !averageLandmarks[index]) {
        return new THREE.Color(0x0000ff);
    }

    const avgLandmark = averageLandmarks[index];
    const distance = Math.sqrt(
        Math.pow(landmark.x - avgLandmark.x, 2) +
        Math.pow(landmark.y - avgLandmark.y, 2) +
        Math.pow(landmark.z - avgLandmark.z, 2)
    );

    const shoulderWidth = Math.abs(landmarks3D[11].x - landmarks3D[12].x);
    const relativeDeviation = distance / shoulderWidth;

    return relativeDeviation > DEVIATION_THRESHOLD ? 
        new THREE.Color(0xff0000) :
        new THREE.Color(0x0000ff);
}

function createPointCloudFromPose(landmarks3D) {
    if (pointCloud) {
        scene.remove(pointCloud);
    }

    const scaleFactor = 2;
    let allPoints = [];
    let colors = [];

    function generatePointsAroundLandmark(landmark, index, radius = 0.08, pointCount = 800) {
        const color = getPointColor(landmark, index, landmarks3D);

        for (let i = 0; i < pointCount; i++) {
            const theta = Math.random() * Math.PI * 2;
            const phi = Math.acos(2 * Math.random() - 1);
            const r = radius * Math.cbrt(Math.random());

            allPoints.push(
                (landmark.x + r * Math.sin(phi) * Math.cos(theta)) * scaleFactor,
                (-landmark.y + r * Math.sin(phi) * Math.sin(theta)) * scaleFactor + 2,
                (-landmark.z + r * Math.cos(phi)) * scaleFactor
            );

            colors.push(color.r, color.g, color.b);
        }
    }

    function generateHeadPoints() {
        const leftEar = landmarks3D[7];
        const rightEar = landmarks3D[8];
        
        const headCenter = {
            x: (leftEar.x + rightEar.x) / 2,
            y: (leftEar.y + rightEar.y) / 2,
            z: (leftEar.z + rightEar.z) / 2
        };

        const headDiameter = Math.hypot(
            leftEar.x - rightEar.x,
            leftEar.y - rightEar.y,
            leftEar.z - rightEar.z
        );

        const leftEarDeviation = getPointColor(leftEar, 7, landmarks3D);
        const rightEarDeviation = getPointColor(rightEar, 8, landmarks3D);
        
        const color = (leftEarDeviation.equals(new THREE.Color(0xff0000)) || 
                      rightEarDeviation.equals(new THREE.Color(0xff0000))) ?
                      new THREE.Color(0xff0000) : new THREE.Color(0x0000ff);

        const pointCount = 2000;
        for (let i = 0; i < pointCount; i++) {
            const theta = Math.random() * Math.PI * 2;
            const phi = Math.acos(2 * Math.random() - 1);
            const r = (headDiameter * 0.6) * Math.cbrt(Math.random());

            allPoints.push(
                (headCenter.x + r * Math.sin(phi) * Math.cos(theta)) * scaleFactor,
                (-headCenter.y + r * Math.sin(phi) * Math.sin(theta)) * scaleFactor + 2,
                (-headCenter.z + r * Math.cos(phi)) * scaleFactor
            );

            colors.push(color.r, color.g, color.b);
        }
    }

    function connectLandmarksWithPoints(start, startIndex, end, endIndex, radius = 0.05, pointCount = 1500) {
        const startColor = getPointColor(start, startIndex, landmarks3D);
        const endColor = getPointColor(end, endIndex, landmarks3D);

        const length = Math.hypot(
            end.x - start.x,
            end.y - start.y,
            end.z - start.z
        );
        const adjustedRadius = radius * Math.min(1, length * 2);

        for (let i = 0; i < pointCount; i++) {
            const t = Math.random();
            const theta = Math.random() * Math.PI * 2;
            const r = adjustedRadius * Math.sqrt(Math.random());

            const x = start.x + (end.x - start.x) * t;
            const y = start.y + (end.y - start.y) * t;
            const z = start.z + (end.z - start.z) * t;

            const color = new THREE.Color(
                startColor.r * (1 - t) + endColor.r * t,
                startColor.g * (1 - t) + endColor.g * t,
                startColor.b * (1 - t) + endColor.b * t
            );

            allPoints.push(
                (x + Math.cos(theta) * r) * scaleFactor,
                (-y + Math.sin(theta) * r) * scaleFactor + 2,
                (-z + (Math.random() - 0.5) * r) * scaleFactor
            );

            colors.push(color.r, color.g, color.b);
        }
    }

    function generateTorsoPoints() {
        const shoulders = {left: landmarks3D[11], right: landmarks3D[12]};
        const hips = {left: landmarks3D[23], right: landmarks3D[24]};

        for (let i = 0; i < 4000; i++) {
            const t = Math.random();
            const upperWidth = Math.abs(shoulders.left.x - shoulders.right.x) * 0.8;
            const lowerWidth = Math.abs(hips.left.x - hips.right.x) * 0.7;
            
            const waistFactor = Math.sin(t * Math.PI) * 0.2;
            const currentWidth = (upperWidth * (1 - t) + lowerWidth * t) * (0.8 - waistFactor);

            const centerX = (shoulders.left.x + shoulders.right.x) / 2 * (1 - t) + 
                          (hips.left.x + hips.right.x) / 2 * t;
            const centerY = shoulders.left.y * (1 - t) + hips.left.y * t;
            const centerZ = (shoulders.left.z + shoulders.right.z) / 2 * (1 - t) + 
                          (hips.left.z + hips.right.z) / 2 * t;

            const point = {
                x: centerX,
                y: centerY,
                z: centerZ
            };

            const color = getPointColor(point, 0, landmarks3D);
            const theta = Math.random() * Math.PI * 2;
            const r = currentWidth * 0.4 * Math.sqrt(Math.random());

            allPoints.push(
                (centerX + Math.cos(theta) * r) * scaleFactor,
                (-centerY + Math.sin(theta) * r) * scaleFactor + 2,
                (-centerZ + (Math.random() - 0.5) * r * 0.5) * scaleFactor
            );

            colors.push(color.r, color.g, color.b);
        }
    }

    const excludedLandmarks = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

    landmarks3D.forEach((landmark, index) => {
        if (!excludedLandmarks.includes(index)) {
            generatePointsAroundLandmark(landmark, index, 0.05, 400);
        }
    });

    const connections = [
        [11, 12], // 肩
        [11, 13], [13, 15], // 左腕
        [12, 14], [14, 16], // 右腕
        [11, 23], [12, 24], // 胴体側面
        [23, 24], // 腰
        [23, 25], [25, 27], // 左脚
        [24, 26], [26, 28]  // 右脚
    ];

    connections.forEach(([i1, i2]) => {
        connectLandmarksWithPoints(landmarks3D[i1], i1, landmarks3D[i2], i2);
    });

    generateTorsoPoints();
    generateHeadPoints();

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(allPoints, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
        size: 0.004,
        sizeAttenuation: true,
        vertexColors: true,
        transparent: true,
        opacity: 0.9
    });

    pointCloud = new THREE.Points(geometry, material);
    scene.add(pointCloud);
}

function onWindowResize() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    
    camera.aspect = width / height;
    if (height > width) {
        camera.fov = 90;
    } else {
        camera.fov = 75;
    }
    camera.updateProjectionMatrix();
    
    renderer.setSize(width, height);
}

window.addEventListener('resize', onWindowResize);

// Initialize and start
initThree();
setupPoseDetection().then(() => {
    console.log('Setup complete');
    animate();
}).catch(error => {
    console.error('Setup failed:', error);
});